#!/usr/bin/env python3
import psycopg2
import time
import re
from googletrans import Translator

# Database connection
conn = psycopg2.connect(
    host="localhost",
    port=5432,
    database="gps_trucks_japan",
    user="postgres",
    password="postgres123"
)
cursor = conn.cursor()

# Initialize translator
translator = Translator()

def has_japanese(text):
    """Check if text contains Japanese characters"""
    return bool(re.search(r'[ぁ-んァ-ヶー]', text))

def clean_translation(text):
    """Clean up common translation issues"""
    # Fix common translation problems
    replacements = {
        'Landcruiser': 'Land Cruiser',
        'hilux surf': 'Hilux Surf',
        'Electric sliding door on both sides': 'Dual Electric Sliding Doors',
        'Both sides electric': 'Dual Electric',
        'Both sides power slide': 'Dual Power Sliding',
        'Rear seat monitor': 'Rear Seat Monitor',
        'Around view monitor': 'Around View Monitor',
        'Half leather seat': 'Half Leather Seats',
        'Sun Roof': 'Sunroof',
        'Back camera': 'Backup Camera',
        'Air conditioner': 'Air Conditioning',
        'Intelligent key': 'Smart Key',
        'Corner sensor': 'Corner Sensors',
        'Drive recorder': 'Dash Cam',
        'One owner car': 'One Owner',
        'Non smoking': 'Non-Smoking',
        'Leather winding steering wheel': 'Leather Steering Wheel',
        'Electric storage mirror': 'Electric Folding Mirrors',
        'Full flat seat': 'Full Flat Seats',
        'Cruise control': 'Cruise Control',
        'inch inch': 'inch'
    }
    
    for old, new in replacements.items():
        text = re.sub(old, new, text, flags=re.IGNORECASE)
    
    # Remove extra spaces
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

def main():
    try:
        print("Connected to database")
        
        # Get all vehicles with Japanese characters
        query = """
            SELECT id, title_description 
            FROM vehicles 
            WHERE title_description ~ '[ぁ-んァ-ヶー]'
            ORDER BY id
        """
        
        cursor.execute(query)
        results = cursor.fetchall()
        print(f"Found {len(results)} titles with Japanese characters")
        
        success_count = 0
        error_count = 0
        
        # Process in batches of 10
        batch_size = 10
        for i in range(0, len(results), batch_size):
            batch = results[i:min(i + batch_size, len(results))]
            
            print(f"Processing batch {i//batch_size + 1}/{(len(results) + batch_size - 1)//batch_size}...")
            
            for row_id, title_description in batch:
                try:
                    # Only translate if it still has Japanese characters
                    if has_japanese(title_description):
                        # Translate the title
                        translated = translator.translate(title_description, src='ja', dest='en')
                        
                        # Clean up the translation
                        cleaned_text = clean_translation(translated.text)
                        
                        # Update the database
                        cursor.execute(
                            "UPDATE vehicles SET title_description = %s WHERE id = %s",
                            (cleaned_text, row_id)
                        )
                        conn.commit()
                        
                        print(f"✓ ID {row_id}: {cleaned_text[:80]}...")
                        success_count += 1
                    else:
                        print(f"- ID {row_id}: Already translated")
                        success_count += 1
                        
                except Exception as error:
                    print(f"✗ ID {row_id}: Translation failed - {error}")
                    error_count += 1
            
            # Small delay between batches to avoid rate limiting
            time.sleep(1)
        
        print(f"\nTranslation complete!")
        print(f"Success: {success_count}")
        print(f"Errors: {error_count}")
        
    except Exception as error:
        print(f"Database error: {error}")
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    main()