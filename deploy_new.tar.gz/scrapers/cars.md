Toyota,Land Cruiser 200,https://www.carsensor.net/usedcar/search.php?CARC=TO_S196&AR=1*7&SKIND=1,https://www.carsensor.net/usedcar/bTO/s196/index2.html?AR=1%2A7,false,1990,20,3,Popular export model - disabled for now
Toyota,Land Cruiser Prado,https://www.carsensor.net/usedcar/index.html?STID=CS210610&AR=1*7&BRDC=&CARC=TO_S152&NINTEI=&CSHOSHO=,https://www.carsensor.net/usedcar/bTO/s152/index2.html?AR=1%2A7,true,1990,15,4,Mid-size SUV
Toyota,Land Cruiser 70 Pickup,https://www.carsensor.net/usedcar/index.html?STID=CS210610&AR=1*7&BRDC=&CARC=TO_S233&NINTEI=&CSHOSHO=,https://www.carsensor.net/usedcar/bTO/s233/index2.html?AR=1%2A7,true,1990,10,5,Pickup variant
Toyota,Land Cruiser 70,https://www.carsensor.net/usedcar/bTO/s149/index.html,https://www.carsensor.net/usedcar/bTO/s149/index2.html,true,1990,15,6,Classic off-road
Toyota,Megacruiser,https://www.carsensor.net/usedcar/index.html?STID=CS210610&AR=0&BRDC=&CARC=TO_S138&NINTEI=&CSHOSHO=,,true,1996,5,7,Rare military-style SUV
Toyota,Vellfire,https://www.carsensor.net/usedcar/bTO/s200/index.html,https://www.carsensor.net/usedcar/bTO/s200/index2.html,true,2008,10,8,Luxury MPV
Toyota,Land Cruiser 100,https://www.carsensor.net/usedcar/bTO/s150/index.html,https://www.carsensor.net/usedcar/bTO/s150/index2.html,true,1998,15,9,Classic full-size SUV
Toyota,Land Cruiser 60,https://www.carsensor.net/usedcar/index.html?STID=CS210610&AR=1*7&BRDC=&CARC=TO_S193&NINTEI=&CSHOSHO=,,true,1980,5,10,Vintage Land Cruiser
Toyota,Hilux Surf,https://www.carsensor.net/usedcar/bTO/s113/index.html,https://www.carsensor.net/usedcar/bTO/s113/index2.html,true,1984,10,11,4Runner equivalent
Toyota,FJ Cruiser,https://www.carsensor.net/usedcar/bTO/s219/index.html,https://www.carsensor.net/usedcar/bTO/s219/index2.html,true,2006,10,12,Retro SUV