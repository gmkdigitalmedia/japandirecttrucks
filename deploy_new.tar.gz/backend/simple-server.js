// Simple working backend for GPS Trucks Japan
require('dotenv').config();
const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
const morgan = require('morgan');
const winston = require('winston');
const compression = require('compression');
const SEOService = require('./seo-service.js');

// Configure logger
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' }),
    new winston.transports.Console({
      format: winston.format.simple()
    })
  ]
});

const app = express();
const port = process.env.PORT || 8000;

// Keep track of running scraper processes
const runningScrapers = new Map(); // jobId -> { process, startTime }

// Database connection
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432'),
  database: process.env.DB_NAME || 'gps_trucks_japan',
  user: process.env.DB_USER || 'gp',
  password: process.env.DB_PASSWORD || 'Megumi12',
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
});

// Middleware
app.use(compression()); // Enable gzip compression
app.use(morgan('combined', { stream: { write: message => logger.info(message.trim()) }}));
app.use(cors({
  origin: ['http://localhost:3000', 'http://localhost:3001'],
  credentials: true
}));
app.use(express.json());

// Request error handling middleware
app.use((err, req, res, next) => {
  logger.error(`Error processing request: ${err.message}`, {
    error: err.stack,
    url: req.url,
    method: req.method,
    body: req.body
  });
  
  res.status(500).json({
    success: false,
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// Serve static images from scraped car_images directory
app.use('/images/scraped', express.static('images/scraped'));

// Image proxy route to serve CarSensor images
app.get('/api/images/proxy', async (req, res) => {
  try {
    const axios = require('axios');
    const imageUrl = req.query.url;
    
    if (!imageUrl) {
      return res.status(400).json({
        success: false,
        error: 'Image URL is required'
      });
    }

    // Handle protocol-relative URLs (starting with //)
    let fullImageUrl = imageUrl;
    if (imageUrl.startsWith('//')) {
      fullImageUrl = 'https:' + imageUrl;
    }

    // Validate that the URL is from CarSensor's CDN
    if (!fullImageUrl.includes('carsensor.net')) {
      return res.status(400).json({
        success: false,
        error: 'Invalid image source'
      });
    }

    // Fetch image with proper headers to bypass CarSensor protection
    const response = await axios.get(fullImageUrl, {
      responseType: 'stream',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': 'https://www.carsensor.net/',
        'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
        'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8',
        'Accept-Encoding': 'gzip, deflate, br',
        'Cache-Control': 'no-cache',
        'Sec-Ch-Ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Platform': '"Windows"',
        'Sec-Fetch-Dest': 'image',
        'Sec-Fetch-Mode': 'no-cors',
        'Sec-Fetch-Site': 'cross-site'
      },
      timeout: 15000,
      maxRedirects: 5
    });

    // Set proper headers for image response
    res.set({
      'Content-Type': response.headers['content-type'] || 'image/jpeg',
      'Content-Length': response.headers['content-length'],
      'Cache-Control': 'public, max-age=86400',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET',
      'Access-Control-Allow-Headers': 'Content-Type'
    });

    // Pipe the image stream directly to the response
    response.data.pipe(res);

  } catch (error) {
    console.error('Image proxy error:', error);
    
    if (error.response && error.response.status === 404) {
      return res.status(404).json({
        success: false,
        error: 'Image not found'
      });
    }
    
    return res.status(500).json({
        success: false,
        error: 'Failed to fetch image'
      });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: 'Backend is healthy!' });
});

// Featured vehicles endpoint
app.get('/api/vehicles/featured', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 8;
    
    const query = `
      SELECT DISTINCT ON (v.id)
        v.*,
        m.name as manufacturer_name,
        md.name as model_name,
        vi.local_path as primary_image_path,
        vi.original_url as primary_image_url
      FROM vehicles v
      LEFT JOIN manufacturers m ON v.manufacturer_id = m.id
      LEFT JOIN models md ON v.model_id = md.id
      LEFT JOIN vehicle_images vi ON v.id = vi.vehicle_id AND vi.is_primary = TRUE
      WHERE v.is_featured = TRUE 
        AND v.is_available = TRUE 
      ORDER BY v.id, v.created_at DESC
      LIMIT $1
    `;
    
    const result = await pool.query(query, [limit]);
    
    const vehicles = result.rows.map(row => ({
      id: row.id,
      title_description: row.title_description,
      price_total_yen: row.price_total_yen,
      price_vehicle_yen: row.price_vehicle_yen,
      model_year_ad: row.model_year_ad,
      mileage_km: row.mileage_km,
      location_prefecture: row.location_prefecture,
      manufacturer: row.manufacturer_name ? { name: row.manufacturer_name } : null,
      model: row.model_name ? { name: row.model_name } : null,
      source_url: row.source_url,
      is_featured: row.is_featured,
      is_available: row.is_available,
      created_at: row.created_at,
      primary_image: row.primary_image_url || null
    }));
    
    console.log(`Returning ${vehicles.length} featured vehicles`);
    
    res.json({
      success: true,
      data: vehicles
    });
  } catch (error) {
    console.error('Featured vehicles error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get featured vehicles',
      details: error.message
    });
  }
});

// Progressive fallback search function
async function performProgressiveSearch(searchQuery, manufacturer, model, page = 1, limit = 10) {
  const offset = (page - 1) * limit;
  
  // Level 1: Enhanced search (existing logic)
  const tryEnhancedSearch = async () => {
    let whereConditions = ['v.is_available = TRUE'];
    let queryParams = [];
    let paramIndex = 1;
    
    // Add manufacturer filter
    if (manufacturer) {
      whereConditions.push(`m.name ILIKE $${paramIndex}`);
      queryParams.push(manufacturer);
      paramIndex++;
    }
    
    // Add model filter
    if (model) {
      whereConditions.push(`md.name ILIKE $${paramIndex}`);
      queryParams.push(model);
      paramIndex++;
    }
    
    // Add search query filter with enhanced matching
    if (searchQuery) {
      const searchTerm = searchQuery.toLowerCase().trim();
      
      // Handle common Land Cruiser variations
      let enhancedSearchConditions = [];
      let enhancedParams = [];
      
      // Base search - original query
      enhancedSearchConditions.push(`(v.title_description ILIKE $${paramIndex} OR m.name ILIKE $${paramIndex} OR md.name ILIKE $${paramIndex})`);
      enhancedParams.push(`%${searchQuery}%`);
      paramIndex++;
      
      // Enhanced search for Land Cruiser variations
      if (searchTerm.includes('landcruiser') || searchTerm === 'landcruiser') {
        enhancedSearchConditions.push(`(v.title_description ILIKE $${paramIndex} OR m.name ILIKE $${paramIndex} OR md.name ILIKE $${paramIndex})`);
        enhancedParams.push(`%land cruiser%`);
        paramIndex++;
      }
      
      // If search contains 'land' but not 'cruiser', include Land Cruiser matches
      if (searchTerm.includes('land') && !searchTerm.includes('cruiser')) {
        enhancedSearchConditions.push(`(v.title_description ILIKE $${paramIndex} OR m.name ILIKE $${paramIndex} OR md.name ILIKE $${paramIndex})`);
        enhancedParams.push(`%land cruiser%`);
        paramIndex++;
      }
      
      // Handle model numbers (70, 100, 200, 300) with Land Cruiser context
      const modelNumbers = searchTerm.match(/\b(70|100|200|300)\b/g);
      if (modelNumbers) {
        for (const modelNum of modelNumbers) {
          enhancedSearchConditions.push(`(v.title_description ILIKE $${paramIndex} OR md.name ILIKE $${paramIndex})`);
          enhancedParams.push(`%land cruiser ${modelNum}%`);
          paramIndex++;
          
          // Also match without space (Land Cruiser200, etc.)
          enhancedSearchConditions.push(`(v.title_description ILIKE $${paramIndex} OR md.name ILIKE $${paramIndex})`);
          enhancedParams.push(`%land cruiser${modelNum}%`);
          paramIndex++;
        }
      }
      
      // Combine all enhanced search conditions with OR
      whereConditions.push(`(${enhancedSearchConditions.join(' OR ')})`);
      queryParams.push(...enhancedParams);
    }
    
    return { whereConditions, queryParams, paramIndex };
  };
  
  // Level 2: Partial word search (if enhanced search fails)
  const tryPartialSearch = async () => {
    let whereConditions = ['v.is_available = TRUE'];
    let queryParams = [];
    let paramIndex = 1;
    
    if (searchQuery) {
      const searchTerm = searchQuery.toLowerCase().trim();
      const words = searchTerm.split(/\s+/).filter(word => word.length >= 2);
      
      if (words.length > 0) {
        const partialConditions = [];
        for (const word of words) {
          partialConditions.push(`(v.title_description ILIKE $${paramIndex} OR m.name ILIKE $${paramIndex} OR md.name ILIKE $${paramIndex})`);
          queryParams.push(`%${word}%`);
          paramIndex++;
        }
        whereConditions.push(`(${partialConditions.join(' OR ')})`);
      }
    }
    
    return { whereConditions, queryParams, paramIndex };
  };
  
  // Level 3: Single character matching (if partial search fails)  
  const trySingleCharSearch = async () => {
    let whereConditions = ['v.is_available = TRUE'];
    let queryParams = [];
    let paramIndex = 1;
    
    if (searchQuery) {
      const searchTerm = searchQuery.toLowerCase().trim().replace(/[^a-zA-Z0-9]/g, '');
      if (searchTerm.length >= 1) {
        // Try to match any single character or number
        const chars = searchTerm.split('').filter(char => char.match(/[a-zA-Z0-9]/));
        if (chars.length > 0) {
          const charConditions = [];
          for (const char of chars.slice(0, 3)) { // Limit to first 3 chars to avoid too broad search
            charConditions.push(`(v.title_description ILIKE $${paramIndex} OR m.name ILIKE $${paramIndex} OR md.name ILIKE $${paramIndex})`);
            queryParams.push(`%${char}%`);
            paramIndex++;
          }
          whereConditions.push(`(${charConditions.join(' OR ')})`);
        }
      }
    }
    
    return { whereConditions, queryParams, paramIndex };
  };
  
  // Level 4: Popular manufacturers/models fallback
  const tryPopularFallback = async () => {
    const whereConditions = [
      'v.is_available = TRUE',
      `(m.name IN ('Toyota', 'Honda', 'Nissan', 'Mazda', 'Subaru') OR md.name ILIKE '%cruiser%' OR md.name ILIKE '%hilux%')`
    ];
    const queryParams = [];
    const paramIndex = 1;
    
    return { whereConditions, queryParams, paramIndex };
  };
  
  // Level 5: Featured vehicles fallback
  const tryFeaturedFallback = async () => {
    const whereConditions = ['v.is_available = TRUE', 'v.is_featured = TRUE'];
    const queryParams = [];
    const paramIndex = 1;
    
    return { whereConditions, queryParams, paramIndex };
  };
  
  // Level 6: Any available vehicles (absolute fallback)
  const tryAnyVehicles = async () => {
    const whereConditions = ['v.is_available = TRUE'];
    const queryParams = [];
    const paramIndex = 1;
    
    return { whereConditions, queryParams, paramIndex };
  };
  
  // Try each search level progressively
  const searchLevels = [
    { name: 'Enhanced Search', func: tryEnhancedSearch },
    { name: 'Partial Word Search', func: tryPartialSearch },
    { name: 'Character Match Search', func: trySingleCharSearch },
    { name: 'Popular Models Fallback', func: tryPopularFallback },
    { name: 'Featured Vehicles Fallback', func: tryFeaturedFallback },
    { name: 'Any Available Vehicles', func: tryAnyVehicles }
  ];
  
  for (const level of searchLevels) {
    try {
      const { whereConditions, queryParams, paramIndex } = await level.func();
      const whereClause = whereConditions.join(' AND ');
      
      // Count query
      const countQuery = `
        SELECT COUNT(*) as total
        FROM vehicles v
        LEFT JOIN manufacturers m ON v.manufacturer_id = m.id
        LEFT JOIN models md ON v.model_id = md.id
        WHERE ${whereClause}
      `;
      
      const countResult = await pool.query(countQuery, queryParams);
      const total = parseInt(countResult.rows[0].total);
      
      if (total > 0) {
        // Found results, get the vehicles
        const vehiclesQuery = `
          SELECT DISTINCT ON (v.id)
            v.*,
            m.name as manufacturer_name,
            md.name as model_name,
            vi.local_path as primary_image_path,
            vi.original_url as primary_image_url
          FROM vehicles v
          LEFT JOIN manufacturers m ON v.manufacturer_id = m.id
          LEFT JOIN models md ON v.model_id = md.id
          LEFT JOIN vehicle_images vi ON v.id = vi.vehicle_id AND vi.is_primary = TRUE
          WHERE ${whereClause}
          ORDER BY v.id, v.created_at DESC
          LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
        `;
        
        const allParams = [...queryParams, limit, offset];
        const vehiclesResult = await pool.query(vehiclesQuery, allParams);
        
        console.log(`Search succeeded at level: ${level.name}, found ${total} results for query: "${searchQuery}"`);
        
        return {
          total,
          vehicles: vehiclesResult.rows,
          searchLevel: level.name
        };
      }
    } catch (error) {
      console.error(`Search level ${level.name} failed:`, error);
      continue; // Try next level
    }
  }
  
  // This should never happen, but just in case
  return {
    total: 0,
    vehicles: [],
    searchLevel: 'No Results'
  };
}

// Main vehicles endpoint - GET all vehicles with pagination and filtering
app.get('/api/vehicles', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 10, 50); // Max 50 per page
    
    // Extract filter parameters
    const { manufacturer, model, q: searchQuery } = req.query;
    
    // Use progressive search
    const searchResult = await performProgressiveSearch(searchQuery, manufacturer, model, page, limit);
    
    const totalPages = Math.ceil(searchResult.total / limit);
    
    const vehicles = searchResult.vehicles.map(row => ({
      id: row.id,
      title_description: row.title_description,
      price_vehicle_yen: row.price_vehicle_yen,
      price_total_yen: row.price_total_yen,
      model_year_ad: row.model_year_ad,
      mileage_km: row.mileage_km,
      manufacturer: row.manufacturer_name ? { name: row.manufacturer_name } : null,
      model: row.model_name ? { name: row.model_name } : null,
      source_url: row.source_url,
      is_featured: row.is_featured,
      is_available: row.is_available,
      created_at: row.created_at,
      primary_image: row.primary_image_url || null
    }));
    
    // Log for debugging
    console.log(`Search completed: manufacturer="${manufacturer}", model="${model}", search="${searchQuery}", level="${searchResult.searchLevel}", found ${searchResult.total} results`);
    
    res.json({
      success: true,
      data: vehicles,
      pagination: {
        page,
        limit,
        total: searchResult.total,
        totalPages,
        hasNext: page < totalPages,
        hasPrev: page > 1
      },
      meta: {
        searchLevel: searchResult.searchLevel,
        originalQuery: searchQuery
      }
    });
  } catch (error) {
    console.error('Get vehicles error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get vehicles',
      details: error.message
    });
  }
});

// Vehicle search endpoint
app.post('/api/vehicles/search', async (req, res) => {
  try {
    console.log('Search request body:', JSON.stringify(req.body));
    console.log('Search request query:', JSON.stringify(req.query));
    console.log('Search request URL:', req.url);
    
    // Parse sort from URL if it's in format "sort=field:order"
    let sortBy = 'created_at';
    let sortOrder = 'DESC';
    
    if (req.query.sort) {
      const [field, order] = req.query.sort.split(':');
      if (field) sortBy = field;
      if (order) sortOrder = order;
    } else if (req.body.sortBy) {
      sortBy = req.body.sortBy;
      sortOrder = req.body.sortOrder || 'DESC';
    }
    
    // Merge body and query params
    const params = { ...req.body, ...req.query };
    const { 
      page = 1, 
      limit = 10,
      manufacturer,
      model,
      query,
      minPrice,
      maxPrice,
      minYear,
      maxYear,
      maxMileage
    } = params;
    
    // Use progressive search but with additional filters for price, year, etc.
    const searchResult = await performProgressiveSearch(query, manufacturer, model, page, limit);
    
    // If we have additional filters and got results, we need to apply them
    if (searchResult.total > 0 && (minPrice || maxPrice || minYear || maxYear || maxMileage)) {
      // Apply additional filters to the base query
      let additionalWhereConditions = ['v.is_available = TRUE'];
      let additionalParams = [];
      let paramIndex = 1;
      
      // Re-apply search conditions from the successful search level
      if (query) {
        // This is a simplified version - in a production system you'd want to reconstruct the exact search
        additionalWhereConditions.push(`(v.title_description ILIKE $${paramIndex} OR m.name ILIKE $${paramIndex} OR md.name ILIKE $${paramIndex})`);
        additionalParams.push(`%${query}%`);
        paramIndex++;
      }
      
      if (manufacturer) {
        additionalWhereConditions.push(`m.name = $${paramIndex}`);
        additionalParams.push(manufacturer);
        paramIndex++;
      }
      
      if (model) {
        additionalWhereConditions.push(`md.name = $${paramIndex}`);
        additionalParams.push(model);
        paramIndex++;
      }
      
      // Add price filters
      if (minPrice) {
        additionalWhereConditions.push(`v.price_total_yen >= $${paramIndex}`);
        additionalParams.push(minPrice);
        paramIndex++;
      }
      
      if (maxPrice) {
        additionalWhereConditions.push(`v.price_total_yen <= $${paramIndex}`);
        additionalParams.push(maxPrice);
        paramIndex++;
      }
      
      // Add year filters
      if (minYear) {
        additionalWhereConditions.push(`v.model_year_ad >= $${paramIndex}`);
        additionalParams.push(minYear);
        paramIndex++;
      }
      
      if (maxYear) {
        additionalWhereConditions.push(`v.model_year_ad <= $${paramIndex}`);
        additionalParams.push(maxYear);
        paramIndex++;
      }
      
      // Add mileage filter
      if (maxMileage) {
        additionalWhereConditions.push(`v.mileage_km <= $${paramIndex}`);
        additionalParams.push(maxMileage);
        paramIndex++;
      }
      
      const whereClause = additionalWhereConditions.join(' AND ');
      
      const searchQuery = `
        WITH sorted_vehicles AS (
          SELECT 
            v.*,
            m.name as manufacturer_name,
            md.name as model_name,
            vi.original_url as primary_image_url,
            COUNT(*) OVER() as total_count
          FROM vehicles v
          LEFT JOIN manufacturers m ON v.manufacturer_id = m.id
          LEFT JOIN models md ON v.model_id = md.id
          LEFT JOIN vehicle_images vi ON v.id = vi.vehicle_id AND vi.is_primary = TRUE
          WHERE ${whereClause}
          ORDER BY v.${sortBy} ${sortOrder}, v.id
        )
        SELECT * FROM sorted_vehicles
        LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
      `;
      
      const offset = (page - 1) * limit;
      additionalParams.push(limit, offset);
      
      const result = await pool.query(searchQuery, additionalParams);
      
      const total = result.rows.length > 0 ? parseInt(result.rows[0].total_count) : 0;
      
      // If filtered results are empty, fall back to progressive search without extra filters
      if (total === 0) {
        console.log('Filtered search returned no results, falling back to progressive search');
        const vehicles = searchResult.vehicles.map(row => ({
          id: row.id,
          title_description: row.title_description,
          price_total_yen: row.price_total_yen,
          price_vehicle_yen: row.price_vehicle_yen,
          model_year_ad: row.model_year_ad,
          mileage_km: row.mileage_km,
          location_prefecture: row.location_prefecture,
          manufacturer: row.manufacturer_name ? { name: row.manufacturer_name } : null,
          model: row.model_name ? { name: row.model_name } : null,
          source_url: row.source_url,
          is_available: row.is_available,
          created_at: row.created_at,
          primary_image: row.primary_image_url || null
        }));
        
        const totalPages = Math.ceil(searchResult.total / limit);
        
        return res.json({
          success: true,
          data: {
            data: vehicles,
            total: searchResult.total,
            page,
            totalPages,
            hasNext: page < totalPages,
            hasPrev: page > 1
          },
          meta: {
            searchLevel: searchResult.searchLevel + ' (Filter Fallback)',
            originalQuery: query,
            note: 'Filters removed to show results'
          }
        });
      }
      
      // Use filtered results
      const vehicles = result.rows.map(row => ({
        id: row.id,
        title_description: row.title_description,
        price_total_yen: row.price_total_yen,
        price_vehicle_yen: row.price_vehicle_yen,
        model_year_ad: row.model_year_ad,
        mileage_km: row.mileage_km,
        location_prefecture: row.location_prefecture,
        manufacturer: row.manufacturer_name ? { name: row.manufacturer_name } : null,
        model: row.model_name ? { name: row.model_name } : null,
        source_url: row.source_url,
        is_available: row.is_available,
        created_at: row.created_at,
        primary_image: row.primary_image_url || null
      }));
      
      const totalPages = Math.ceil(total / limit);
      
      return res.json({
        success: true,
        data: {
          data: vehicles,
          total,
          page,
          totalPages,
          hasNext: page < totalPages,
          hasPrev: page > 1
        },
        meta: {
          searchLevel: searchResult.searchLevel + ' (Filtered)',
          originalQuery: query
        }
      });
    }
    
    // No additional filters or progressive search returned no results, use progressive search result
    const vehicles = searchResult.vehicles.map(row => ({
      id: row.id,
      title_description: row.title_description,
      price_total_yen: row.price_total_yen,
      price_vehicle_yen: row.price_vehicle_yen,
      model_year_ad: row.model_year_ad,
      mileage_km: row.mileage_km,
      location_prefecture: row.location_prefecture,
      manufacturer: row.manufacturer_name ? { name: row.manufacturer_name } : null,
      model: row.model_name ? { name: row.model_name } : null,
      source_url: row.source_url,
      is_available: row.is_available,
      created_at: row.created_at,
      primary_image: row.primary_image_url || null
    }));
    
    const totalPages = Math.ceil(searchResult.total / limit);
    
    res.json({
      success: true,
      data: {
        data: vehicles,
        total: searchResult.total,
        page,
        totalPages,
        hasNext: page < totalPages,
        hasPrev: page > 1
      },
      meta: {
        searchLevel: searchResult.searchLevel,
        originalQuery: query
      }
    });
  } catch (error) {
    console.error('Search error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to search vehicles',
      details: error.message
    });
  }
});

// Manufacturers endpoint
app.get('/api/manufacturers', async (req, res) => {
  try {
    const query = `
      SELECT 
        m.id,
        m.name,
        m.country,
        COUNT(v.id) as vehicle_count
      FROM manufacturers m
      LEFT JOIN vehicles v ON m.id = v.manufacturer_id AND v.is_available = TRUE
      WHERE m.is_active = TRUE
      GROUP BY m.id, m.name, m.country
      HAVING COUNT(v.id) > 0
      ORDER BY COUNT(v.id) DESC, m.name
    `;
    
    const result = await pool.query(query);
    
    res.json({
      success: true,
      data: result.rows
    });
  } catch (error) {
    console.error('Manufacturers error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get manufacturers',
      details: error.message
    });
  }
});

// Models for a manufacturer endpoint
app.get('/api/manufacturers/:manufacturerId/models', async (req, res) => {
  try {
    const { manufacturerId } = req.params;
    
    const query = `
      SELECT 
        md.id,
        md.name,
        md.body_type,
        COUNT(v.id) as vehicle_count
      FROM models md
      LEFT JOIN vehicles v ON md.id = v.model_id AND v.is_available = TRUE
      WHERE md.manufacturer_id = $1
      GROUP BY md.id, md.name, md.body_type
      HAVING COUNT(v.id) > 0
      ORDER BY COUNT(v.id) DESC, md.name
    `;
    
    const result = await pool.query(query, [manufacturerId]);
    
    res.json({
      success: true,
      data: result.rows
    });
  } catch (error) {
    console.error('Models error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get models',
      details: error.message
    });
  }
});

// Vehicles for a specific model endpoint
app.get('/api/models/:modelId/vehicles', async (req, res) => {
  try {
    const { modelId } = req.params;
    const { page = 1, limit = 12 } = req.query;
    
    // First get total count for pagination
    const countQuery = `
      SELECT COUNT(*) as total
      FROM vehicles v
      WHERE v.model_id = $1 AND v.is_available = TRUE
    `;
    const countResult = await pool.query(countQuery, [modelId]);
    const totalCount = parseInt(countResult.rows[0].total);
    
    const query = `
      SELECT DISTINCT ON (v.id)
        v.*,
        m.name as manufacturer_name,
        md.name as model_name,
        vi.original_url as primary_image_url
      FROM vehicles v
      LEFT JOIN manufacturers m ON v.manufacturer_id = m.id
      LEFT JOIN models md ON v.model_id = md.id
      LEFT JOIN vehicle_images vi ON v.id = vi.vehicle_id AND vi.is_primary = TRUE
      WHERE v.model_id = $1 AND v.is_available = TRUE
      ORDER BY v.id, v.created_at DESC
      LIMIT $2 OFFSET $3
    `;
    
    const offset = (page - 1) * limit;
    const result = await pool.query(query, [modelId, limit, offset]);
    
    const vehicles = result.rows.map(row => ({
      id: row.id,
      title_description: row.title_description,
      price_total_yen: row.price_total_yen,
      price_vehicle_yen: row.price_vehicle_yen,
      model_year_ad: row.model_year_ad,
      mileage_km: row.mileage_km,
      location_prefecture: row.location_prefecture,
      manufacturer: row.manufacturer_name ? { name: row.manufacturer_name } : null,
      model: row.model_name ? { name: row.model_name } : null,
      source_url: row.source_url,
      is_featured: row.is_featured,
      is_available: row.is_available,
      created_at: row.created_at,
      primary_image: row.primary_image_url || null
    }));
    
    const currentPage = parseInt(page);
    const totalPages = Math.ceil(totalCount / limit);
    const hasMore = currentPage < totalPages;
    
    res.json({
      success: true,
      data: vehicles,
      pagination: {
        currentPage,
        totalPages,
        totalCount,
        hasMore,
        limit: parseInt(limit)
      }
    });
  } catch (error) {
    console.error('Model vehicles error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get model vehicles',
      details: error.message
    });
  }
});

// AI Analysis Generation Function
function generateAIAnalysis(vehicle) {
  const currentYear = new Date().getFullYear();
  const vehicleAge = currentYear - vehicle.model_year_ad;
  const avgKmPerYear = 11000; // 11,000 km per year average
  const expectedMileage = vehicleAge * avgKmPerYear;
  
  // Calculate USA price estimate based on vehicle data
  let usaPriceEstimate;
  if (vehicle.model_name && vehicle.model_name.includes('Land Cruiser')) {
    // Land Cruiser pricing in USA
    if (vehicle.model_name.includes('300')) {
      usaPriceEstimate = Math.round(80000 + (2025 - vehicle.model_year_ad) * -3000); // LC300 starts ~$80k
    } else if (vehicle.model_name.includes('200')) {
      usaPriceEstimate = Math.round(64852 + (2025 - vehicle.model_year_ad) * -2500); // LC200 used prices
    } else {
      usaPriceEstimate = Math.round(50000 + (2025 - vehicle.model_year_ad) * -2000); // Prado/other LC
    }
  } else if (vehicle.model_name && vehicle.model_name.includes('Hijet')) {
    usaPriceEstimate = Math.round(25000 + (2025 - vehicle.model_year_ad) * -1500); // Kei trucks
  } else {
    // Generic estimation
    usaPriceEstimate = Math.round(40000 + (2025 - vehicle.model_year_ad) * -2000);
  }
  
  // Ensure minimum price
  usaPriceEstimate = Math.max(usaPriceEstimate, 15000);
  
  const vehiclePriceUSD = Math.round(vehicle.price_total_yen / 150); // Convert to USD
  const savingsAmount = Math.max(0, usaPriceEstimate - vehiclePriceUSD);
  const savingsPercentage = usaPriceEstimate > 0 ? Math.round((savingsAmount / usaPriceEstimate) * 100) : 0;
  
  // Generate confidence score based on various factors
  let confidenceScore = 7; // Base score
  
  // Adjust for mileage
  if (vehicle.mileage_km < expectedMileage * 0.7) confidenceScore += 1; // Low mileage bonus
  if (vehicle.mileage_km > expectedMileage * 1.5) confidenceScore -= 1; // High mileage penalty
  
  // Adjust for age
  if (vehicleAge < 5) confidenceScore += 1; // Newer vehicle bonus
  if (vehicleAge > 15) confidenceScore -= 1; // Older vehicle penalty
  
  // Adjust for savings
  if (savingsPercentage > 30) confidenceScore += 1; // Great deal bonus
  
  // Clamp between 1-10
  confidenceScore = Math.max(1, Math.min(10, confidenceScore));
  
  return {
    value_headline: `Save $${savingsAmount.toLocaleString()} vs USA market`,
    mileage_advantage: vehicle.mileage_km < expectedMileage ? 
      `${Math.round((expectedMileage - vehicle.mileage_km) / 1000)}k km below average` :
      `${Math.round((vehicle.mileage_km - expectedMileage) / 1000)}k km above average`,
    key_benefits: [
      "Japanese maintenance standards",
      "Export documentation included", 
      "Professional inspection",
      savingsPercentage > 20 ? "Exceptional value" : "Competitive pricing"
    ],
    market_comparison: `Compared to similar ${vehicle.model_year_ad} ${vehicle.manufacturer_name || ''} ${vehicle.model_name || ''} in USA market`,
    confidence_score: confidenceScore,
    usa_price_estimate: usaPriceEstimate,
    savings_amount: savingsAmount,
    savings_percentage: savingsPercentage
  };
}

// Stats endpoint - must come before /:id endpoint
app.get('/api/vehicles/stats', async (req, res) => {
  try {
    const queries = [
      'SELECT COUNT(*) as total FROM vehicles',
      'SELECT COUNT(*) as available FROM vehicles WHERE is_available = TRUE',
      'SELECT COUNT(*) as featured FROM vehicles WHERE is_featured = TRUE',
      'SELECT COUNT(*) as inquiries FROM inquiries'
    ];
    
    const results = await Promise.all(
      queries.map(query => pool.query(query))
    );
    
    res.json({
      success: true,
      data: {
        totalVehicles: parseInt(results[0].rows[0].total),
        availableVehicles: parseInt(results[1].rows[0].available),
        featuredVehicles: parseInt(results[2].rows[0].featured),
        totalInquiries: parseInt(results[3].rows[0].inquiries)
      }
    });
  } catch (error) {
    console.error('Stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get stats',
      details: error.message
    });
  }
});

// Sitemap endpoint - returns all vehicle IDs and update dates
app.get('/api/vehicles/sitemap', async (req, res) => {
  try {
    const query = `
      SELECT id, updated_at 
      FROM vehicles 
      WHERE is_available = TRUE 
      ORDER BY id
    `;
    
    const result = await pool.query(query);
    
    res.json({
      success: true,
      data: result.rows
    });
  } catch (error) {
    console.error('Sitemap endpoint error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get sitemap data',
      details: error.message
    });
  }
});

// Individual vehicle endpoint
app.get('/api/vehicles/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log('🔍 Vehicle detail request for ID:', id);
    
    const query = `
      SELECT 
        v.*,
        m.name as manufacturer_name,
        md.name as model_name,
        json_agg(
          json_build_object(
            'url', vi.original_url,
            'alt_text', vi.alt_text,
            'is_primary', vi.is_primary
          ) ORDER BY vi.image_order, vi.is_primary DESC
        ) FILTER (WHERE vi.id IS NOT NULL) as images
      FROM vehicles v
      LEFT JOIN manufacturers m ON v.manufacturer_id = m.id
      LEFT JOIN models md ON v.model_id = md.id
      LEFT JOIN vehicle_images vi ON v.id = vi.vehicle_id
      WHERE v.id = $1 AND v.is_available = TRUE
      GROUP BY v.id, m.name, md.name
    `;
    
    const result = await pool.query(query, [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Vehicle not found'
      });
    }
    
    const row = result.rows[0];
    
    // GENERATE SEO ON-THE-FLY IF MISSING
    let seoMetadata = row.seo_metadata;
    console.log(`🔍 Vehicle ${id} SEO debug:`, {
      has_seo: !!seoMetadata,
      seo_type: typeof seoMetadata,
      seo_keys: seoMetadata ? Object.keys(seoMetadata) : null
    });
    if (!seoMetadata) {
      console.log(`⚠️ Vehicle ${id} missing SEO, generating now...`);
      
      // Generate SEO immediately
      const vehicleData = {
        id: row.id,
        model_year_ad: row.model_year_ad,
        mileage_km: row.mileage_km,
        price_vehicle_yen: row.price_vehicle_yen,
        price_total_yen: row.price_total_yen,
        grade: row.grade,
        is_accident_free: row.is_accident_free,
        is_one_owner: row.is_one_owner,
        has_warranty: row.has_warranty,
        manufacturer_name: row.manufacturer_name,
        model_name: row.model_name
      };
      
      seoMetadata = {
        title: seoService.generateTitle(vehicleData),
        description: seoService.generateDescription(vehicleData),
        keywords: seoService.generateKeywords(vehicleData),
        og_title: `${vehicleData.model_year_ad} ${vehicleData.manufacturer_name} ${vehicleData.model_name} - Export from Japan`,
        og_description: seoService.generateDescription(vehicleData),
        canonical_url: `https://japandirecttrucks.com/vehicles/${row.id}`
      };
      
      // Save to database in background (don't wait)
      seoService.updateVehicleSEO(row.id, seoMetadata).catch(err => {
        console.error(`Failed to save SEO for vehicle ${row.id}:`, err);
      });
    }
    
    const vehicle = {
      id: row.id,
      title_description: row.title_description,
      price_total_yen: row.price_total_yen,
      price_vehicle_yen: row.price_vehicle_yen,
      model_year_ad: row.model_year_ad,
      mileage_km: row.mileage_km,
      location_prefecture: row.location_prefecture,
      transmission_type: row.transmission_type,
      drivetrain_type: row.drivetrain_type,
      fuel_type: row.fuel_type,
      engine_displacement: row.engine_displacement,
      has_repair_history: row.has_repair_history,
      has_warranty: row.has_warranty,
      dealer_name: row.dealer_name,
      features: row.features,
      detail_specs: row.detail_specs,
      manufacturer: row.manufacturer_name ? { name: row.manufacturer_name } : null,
      model: row.model_name ? { name: row.model_name } : null,
      source_url: row.source_url,
      is_featured: row.is_featured,
      is_available: row.is_available,
      created_at: row.created_at,
      images: row.images || [],
      seo_metadata: row.seo_metadata, // Use database SEO metadata directly
      ai_description: row.ai_description
    };
    
    // Parse AI description and extract market data if available
    let cleanDescription = row.ai_description || '';
    let aiAnalysis = null;
    
    // Check if ai_description is JSON format
    if (cleanDescription && cleanDescription.startsWith('{')) {
      try {
        const parsed = JSON.parse(cleanDescription);
        
        if (parsed.market_data && parsed.description) {
          // New format: {"market_data": {...}, "description": "..."}
          cleanDescription = parsed.description;
          const marketData = parsed.market_data;
          
          aiAnalysis = {
          value_headline: `Save $${(marketData.savings_amount || 0).toLocaleString()} vs USA market`,
          mileage_advantage: vehicle.mileage_km < (vehicle.model_year_ad ? (2025 - vehicle.model_year_ad) * 11000 : 50000) ? 
            'Below average mileage' : 'Average mileage',
          key_benefits: [
            "Japanese maintenance standards",
            "Export documentation included", 
            "Professional inspection",
            marketData.savings_percentage > 20 ? "Exceptional value" : "Competitive pricing"
          ],
          market_comparison: `Compared to similar ${vehicle.model_year_ad} ${row.manufacturer_name || ''} ${row.model_name || ''} in USA market`,
          confidence_score: marketData.savings_percentage > 30 ? 9 : 7,
          usa_price_estimate: marketData.usa_price_estimate || 0,
          savings_amount: marketData.savings_amount || 0,
          savings_percentage: marketData.savings_percentage || 0
        };
        } else {
          // Might be old format, just use as description
          cleanDescription = cleanDescription;
        }
      } catch (e) {
        console.log('Could not parse JSON from AI description');
      }
    } else if (cleanDescription && cleanDescription.includes('<!--MARKET_DATA:')) {
      // Old format with HTML comment (backward compatibility)
      const parts = cleanDescription.split('<!--MARKET_DATA:');
      cleanDescription = parts[0].trim();
      
      try {
        const jsonStr = parts[1].replace('-->', '').trim();
        const marketData = JSON.parse(jsonStr);
        
        aiAnalysis = {
          value_headline: `Save $${(marketData.savings_amount || 0).toLocaleString()} vs USA market`,
          mileage_advantage: vehicle.mileage_km < (vehicle.model_year_ad ? (2025 - vehicle.model_year_ad) * 11000 : 50000) ? 
            'Below average mileage' : 'Average mileage',
          key_benefits: [
            "Japanese maintenance standards",
            "Export documentation included", 
            "Professional inspection",
            marketData.savings_percentage > 20 ? "Exceptional value" : "Competitive pricing"
          ],
          market_comparison: `Compared to similar ${vehicle.model_year_ad} ${row.manufacturer_name || ''} ${row.model_name || ''} in USA market`,
          confidence_score: marketData.savings_percentage > 30 ? 9 : 7,
          usa_price_estimate: marketData.usa_price_estimate || 0,
          savings_amount: marketData.savings_amount || 0,
          savings_percentage: marketData.savings_percentage || 0
        };
      } catch (e) {
        console.log('Could not parse market data from HTML comment');
      }
    }
    
    // If no AI market data, generate it dynamically (fallback)
    if (!aiAnalysis) {
      aiAnalysis = generateAIAnalysis({
        ...vehicle,
        manufacturer_name: row.manufacturer_name,
        model_name: row.model_name
      });
    }
    
    vehicle.ai_description = cleanDescription;
    vehicle.ai_analysis = aiAnalysis;
    
    res.json({
      success: true,
      data: vehicle
    });
  } catch (error) {
    console.error('Vehicle details error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get vehicle details',
      details: error.message
    });
  }
});

// Similar vehicles endpoint
app.get('/api/vehicles/:id/similar', async (req, res) => {
  try {
    const { id } = req.params;
    const { limit = 6 } = req.query;
    
    // First get the current vehicle's details
    const currentVehicle = await pool.query(
      'SELECT manufacturer_id, model_id, price_vehicle_yen FROM vehicles WHERE id = $1',
      [id]
    );
    
    if (currentVehicle.rows.length === 0) {
      return res.json({ success: true, data: [] });
    }
    
    const { manufacturer_id, model_id, price_vehicle_yen } = currentVehicle.rows[0];
    const priceRange = price_vehicle_yen * 0.3; // 30% price range
    
    const query = `
      SELECT DISTINCT ON (v.id)
        v.*,
        m.name as manufacturer_name,
        md.name as model_name,
        vi.original_url as primary_image_url
      FROM vehicles v
      LEFT JOIN manufacturers m ON v.manufacturer_id = m.id
      LEFT JOIN models md ON v.model_id = md.id
      LEFT JOIN vehicle_images vi ON v.id = vi.vehicle_id AND vi.is_primary = TRUE
      WHERE v.id != $1 
        AND v.is_available = TRUE
        AND (
          v.manufacturer_id = $2 
          OR v.model_id = $3
          OR (v.price_vehicle_yen BETWEEN $4 AND $5)
        )
      ORDER BY v.id,
        CASE WHEN v.model_id = $3 THEN 1 ELSE 2 END,
        CASE WHEN v.manufacturer_id = $2 THEN 1 ELSE 2 END,
        ABS(v.price_vehicle_yen - $6),
        v.created_at DESC
      LIMIT $7
    `;
    
    const result = await pool.query(query, [
      id, 
      manufacturer_id, 
      model_id, 
      price_vehicle_yen - priceRange,
      price_vehicle_yen + priceRange,
      price_vehicle_yen,
      limit
    ]);
    
    const vehicles = result.rows.map(row => ({
      id: row.id,
      title_description: row.title_description,
      price_total_yen: row.price_total_yen,
      price_vehicle_yen: row.price_vehicle_yen,
      model_year_ad: row.model_year_ad,
      mileage_km: row.mileage_km,
      location_prefecture: row.location_prefecture,
      manufacturer: row.manufacturer_name ? { name: row.manufacturer_name } : null,
      model: row.model_name ? { name: row.model_name } : null,
      source_url: row.source_url,
      is_featured: row.is_featured,
      is_available: row.is_available,
      created_at: row.created_at,
      primary_image: row.primary_image_url || null
    }));
    
    res.json({
      success: true,
      data: vehicles
    });
  } catch (error) {
    console.error('Similar vehicles error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get similar vehicles',
      details: error.message
    });
  }
});

// Inquiries endpoint
app.post('/api/inquiries', async (req, res) => {
  try {
    const {
      name,
      email,
      phone,
      company,
      country,
      subject,
      message,
      vehicleInterest,
      type,
      source,
      vehicle_id
    } = req.body;

    // Insert inquiry into database
    const query = `
      INSERT INTO inquiries (
        customer_name, customer_email, customer_phone, customer_country, 
        message, inquiry_type, status, vehicle_id
      ) VALUES (
        $1, $2, $3, $4, $5, $6, 'new', $7
      ) RETURNING id
    `;

    const result = await pool.query(query, [
      name,
      email,
      phone || null,
      country,
      `${subject}: ${message}` || message || null,
      type || 'general',
      vehicle_id || null
    ]);

    const inquiryId = result.rows[0].id;

    console.log(`📧 New inquiry received: ${inquiryId} from ${name} (${email})`);

    res.json({
      success: true,
      message: 'Inquiry submitted successfully',
      data: { id: inquiryId }
    });

  } catch (error) {
    console.error('Error submitting inquiry:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to submit inquiry',
      details: error.message
    });
  }
});

// Create inquiries table if it doesn't exist
pool.query(`
  CREATE TABLE IF NOT EXISTS inquiries (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    company VARCHAR(255),
    country VARCHAR(100),
    subject VARCHAR(500) NOT NULL,
    message TEXT NOT NULL,
    vehicle_interest VARCHAR(255),
    type VARCHAR(50) DEFAULT 'general',
    source VARCHAR(100) DEFAULT 'website',
    vehicle_id INTEGER REFERENCES vehicles(id),
    status VARCHAR(50) DEFAULT 'new',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
  )
`).then(() => {
  console.log('✅ Inquiries table ready');
}).catch(err => {
  console.error('❌ Error creating inquiries table:', err);
});

// User authentication endpoints
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

// Translation function for vehicle titles
async function translateAndCleanTitle(originalTitle) {
  try {
    // First check if translation is needed (contains Japanese characters)
    if (!/[ぁ-んァ-ヶー]/.test(originalTitle)) {
      // No Japanese characters, just clean up common issues
      return cleanupTitle(originalTitle);
    }

    // Import translate function dynamically
    const { translate } = require('@vitalets/google-translate-api');
    
    // Translate from Japanese to English
    const translated = await translate(originalTitle, {from: 'ja', to: 'en'});
    
    return cleanupTitle(translated.text);
  } catch (error) {
    console.error('Translation failed:', error);
    // If translation fails, just clean up the original title
    return cleanupTitle(originalTitle);
  }
}

// Clean up vehicle titles (common fixes)
function cleanupTitle(text) {
  return text
    .replace(/Land Cruiser Prado/gi, 'Landcruiser Prado')
    .replace(/LandcruiserPrado/gi, 'Landcruiser Prado')
    .replace(/Land CruiserPrado/gi, 'Landcruiser Prado')
    .replace(/CruiserPrado/gi, 'cruiser Prado')
    .replace(/Land Cruiser/gi, 'Landcruiser')
    .replace(/hilux surf/gi, 'Hilux Surf')
    .replace(/FJ Cruiser/gi, 'FJ Cruiser')
    .replace(/Electric sliding door on both sides/gi, 'Dual Electric Sliding Doors')
    .replace(/Both sides electric/gi, 'Dual Electric')
    .replace(/Both sides power slide/gi, 'Dual Power Sliding')
    .replace(/Rear seat monitor/gi, 'Rear Seat Monitor')
    .replace(/Around view monitor/gi, 'Around View Monitor')
    .replace(/Half leather seat/gi, 'Half Leather Seats')
    .replace(/Sun Roof/gi, 'Sunroof')
    .replace(/Back camera/gi, 'Backup Camera')
    .replace(/Air conditioner/gi, 'Air Conditioning')
    .replace(/Intelligent key/gi, 'Smart Key')
    .replace(/Corner sensor/gi, 'Corner Sensors')
    .replace(/Drive recorder/gi, 'Dash Cam')
    .replace(/One owner car/gi, 'One Owner')
    .replace(/Non smoking/gi, 'Non-Smoking')
    .replace(/Leather winding steering wheel/gi, 'Leather Steering Wheel')
    .replace(/Electric storage mirror/gi, 'Electric Folding Mirrors')
    .replace(/Full flat seat/gi, 'Full Flat Seats')
    .replace(/Cruise control/gi, 'Cruise Control')
    .replace(/inch inch/gi, 'inch')
    .replace(/  +/g, ' ') // Remove extra spaces
    .trim();
}

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ success: false, error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// User registration
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password, phone, country } = req.body;

    // Validation
    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Name, email, and password are required'
      });
    }

    // Check if user already exists
    const existingUser = await pool.query(
      'SELECT id FROM users WHERE email = $1',
      [email.toLowerCase()]
    );

    if (existingUser.rows.length > 0) {
      return res.status(400).json({
        success: false,
        error: 'User with this email already exists'
      });
    }

    // Hash password
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    // Insert user
    const result = await pool.query(`
      INSERT INTO users (name, email, password_hash, phone, country, created_at)
      VALUES ($1, $2, $3, $4, $5, NOW())
      RETURNING id, name, email, phone, country, created_at
    `, [name, email.toLowerCase(), hashedPassword, phone || null, country || null]);

    const user = result.rows[0];

    // Generate JWT token
    const token = jwt.sign(
      { userId: user.id, email: user.email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      success: true,
      message: 'User registered successfully',
      data: {
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          phone: user.phone,
          country: user.country,
          created_at: user.created_at
        },
        token
      }
    });

  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to register user',
      details: error.message
    });
  }
});

// User login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Email and password are required'
      });
    }

    // Find user
    const result = await pool.query(
      'SELECT id, name, email, password_hash, phone, country, created_at FROM users WHERE email = $1',
      [email.toLowerCase()]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({
        success: false,
        error: 'Invalid email or password'
      });
    }

    const user = result.rows[0];

    // Verify password
    const validPassword = await bcrypt.compare(password, user.password_hash);
    if (!validPassword) {
      return res.status(401).json({
        success: false,
        error: 'Invalid email or password'
      });
    }

    // Generate JWT token
    const token = jwt.sign(
      { userId: user.id, email: user.email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      success: true,
      message: 'Login successful',
      data: {
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          phone: user.phone,
          country: user.country,
          created_at: user.created_at
        },
        token
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to login',
      details: error.message
    });
  }
});

// Get current user
app.get('/api/auth/me', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, name, email, phone, country, created_at FROM users WHERE id = $1',
      [req.user.userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    res.json({
      success: true,
      data: { user: result.rows[0] }
    });

  } catch (error) {
    console.error('Get current user error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get user data'
    });
  }
});

// User favorites endpoints
// Add vehicle to favorites
app.post('/api/favorites', authenticateToken, async (req, res) => {
  try {
    const { vehicle_id } = req.body;
    const userId = req.user.userId;

    if (!vehicle_id) {
      return res.status(400).json({
        success: false,
        error: 'Vehicle ID is required'
      });
    }

    // Check if already favorited
    const existing = await pool.query(
      'SELECT id FROM user_favorites WHERE user_id = $1 AND vehicle_id = $2',
      [userId, vehicle_id]
    );

    if (existing.rows.length > 0) {
      return res.status(400).json({
        success: false,
        error: 'Vehicle already in favorites'
      });
    }

    // Add to favorites
    await pool.query(
      'INSERT INTO user_favorites (user_id, vehicle_id, created_at) VALUES ($1, $2, NOW())',
      [userId, vehicle_id]
    );

    res.json({
      success: true,
      message: 'Vehicle added to favorites'
    });

  } catch (error) {
    console.error('Add favorite error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to add favorite'
    });
  }
});

// Remove vehicle from favorites
app.delete('/api/favorites/:vehicleId', authenticateToken, async (req, res) => {
  try {
    const vehicleId = req.params.vehicleId;
    const userId = req.user.userId;

    await pool.query(
      'DELETE FROM user_favorites WHERE user_id = $1 AND vehicle_id = $2',
      [userId, vehicleId]
    );

    res.json({
      success: true,
      message: 'Vehicle removed from favorites'
    });

  } catch (error) {
    console.error('Remove favorite error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to remove favorite'
    });
  }
});

// Get user favorites
app.get('/api/favorites', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.userId;
    
    const query = `
      SELECT DISTINCT ON (v.id)
        v.*,
        m.name as manufacturer_name,
        md.name as model_name,
        vi.local_path as primary_image_path,
        vi.original_url as primary_image_url,
        uf.created_at as favorited_at
      FROM user_favorites uf
      JOIN vehicles v ON uf.vehicle_id = v.id
      LEFT JOIN manufacturers m ON v.manufacturer_id = m.id
      LEFT JOIN models md ON v.model_id = md.id
      LEFT JOIN vehicle_images vi ON v.id = vi.vehicle_id AND vi.is_primary = TRUE
      WHERE uf.user_id = $1
      ORDER BY v.id, uf.created_at DESC
    `;
    
    const result = await pool.query(query, [userId]);
    
    const favorites = result.rows.map(row => ({
      id: row.id,
      title_description: row.title_description,
      price_total_yen: row.price_total_yen,
      price_vehicle_yen: row.price_vehicle_yen,
      model_year_ad: row.model_year_ad,
      mileage_km: row.mileage_km,
      location_prefecture: row.location_prefecture,
      manufacturer: row.manufacturer_name ? { name: row.manufacturer_name } : null,
      model: row.model_name ? { name: row.model_name } : null,
      source_url: row.source_url,
      is_featured: row.is_featured,
      is_available: row.is_available,
      created_at: row.created_at,
      favorited_at: row.favorited_at,
      primary_image: row.primary_image_url || null
    }));

    res.json({
      success: true,
      data: favorites
    });

  } catch (error) {
    console.error('Get favorites error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get favorites'
    });
  }
});

// Admin endpoint to get all inquiries
app.get('/api/admin/inquiries', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const offset = (page - 1) * limit;

    const query = `
      SELECT 
        i.*,
        v.title_description as vehicle_title
      FROM inquiries i
      LEFT JOIN vehicles v ON i.vehicle_id = v.id
      ORDER BY i.created_at DESC
      LIMIT $1 OFFSET $2
    `;

    const countQuery = 'SELECT COUNT(*) FROM inquiries';
    
    const [result, countResult] = await Promise.all([
      pool.query(query, [limit, offset]),
      pool.query(countQuery)
    ]);

    const total = parseInt(countResult.rows[0].count);
    const totalPages = Math.ceil(total / limit);

    res.json({
      success: true,
      data: {
        inquiries: result.rows,
        pagination: {
          page,
          limit,
          total,
          totalPages
        }
      }
    });

  } catch (error) {
    console.error('Get inquiries error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get inquiries'
    });
  }
});

// Create users table if it doesn't exist
pool.query(`
  CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    country VARCHAR(100),
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
  )
`).then(() => {
  console.log('✅ Users table ready');
}).catch(err => {
  console.error('❌ Error creating users table:', err);
});

// Create user_favorites table if it doesn't exist
pool.query(`
  CREATE TABLE IF NOT EXISTS user_favorites (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    vehicle_id INTEGER REFERENCES vehicles(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(user_id, vehicle_id)
  )
`).then(() => {
  console.log('✅ User favorites table ready');
}).catch(err => {
  console.error('❌ Error creating user_favorites table:', err);
});

// Admin makes and models management endpoints
app.get('/api/admin/makes', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM manufacturers ORDER BY name');
    res.json({
      success: true,
      data: result.rows
    });
  } catch (error) {
    console.error('Get makes error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get makes'
    });
  }
});

app.post('/api/admin/makes', async (req, res) => {
  try {
    const { name } = req.body;
    
    if (!name) {
      return res.status(400).json({
        success: false,
        error: 'Make name is required'
      });
    }
    
    // Check if make already exists
    const existing = await pool.query(
      'SELECT id FROM manufacturers WHERE LOWER(name) = LOWER($1)',
      [name]
    );
    
    if (existing.rows.length > 0) {
      return res.status(400).json({
        success: false,
        error: 'Make already exists'
      });
    }
    
    const result = await pool.query(
      'INSERT INTO manufacturers (name) VALUES ($1) RETURNING *',
      [name]
    );
    
    res.json({
      success: true,
      data: result.rows[0]
    });
  } catch (error) {
    console.error('Add make error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to add make'
    });
  }
});

app.delete('/api/admin/makes/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Check if make has associated models
    const models = await pool.query(
      'SELECT COUNT(*) FROM models WHERE manufacturer_id = $1',
      [id]
    );
    
    if (parseInt(models.rows[0].count) > 0) {
      return res.status(400).json({
        success: false,
        error: 'Cannot delete make with associated models'
      });
    }
    
    await pool.query('DELETE FROM manufacturers WHERE id = $1', [id]);
    
    res.json({
      success: true,
      message: 'Make deleted successfully'
    });
  } catch (error) {
    console.error('Delete make error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete make'
    });
  }
});

app.get('/api/admin/models', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT m.*, man.name as manufacturer_name 
      FROM models m
      JOIN manufacturers man ON m.manufacturer_id = man.id
      ORDER BY man.name, m.name
    `);
    res.json({
      success: true,
      data: result.rows
    });
  } catch (error) {
    console.error('Get models error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get models'
    });
  }
});

app.post('/api/admin/models', async (req, res) => {
  try {
    const { name, manufacturer_id } = req.body;
    
    if (!name || !manufacturer_id) {
      return res.status(400).json({
        success: false,
        error: 'Model name and manufacturer are required'
      });
    }
    
    // Check if model already exists for this manufacturer
    const existing = await pool.query(
      'SELECT id FROM models WHERE LOWER(name) = LOWER($1) AND manufacturer_id = $2',
      [name, manufacturer_id]
    );
    
    if (existing.rows.length > 0) {
      return res.status(400).json({
        success: false,
        error: 'Model already exists for this manufacturer'
      });
    }
    
    const result = await pool.query(
      'INSERT INTO models (name, manufacturer_id) VALUES ($1, $2) RETURNING *',
      [name, manufacturer_id]
    );
    
    res.json({
      success: true,
      data: result.rows[0]
    });
  } catch (error) {
    console.error('Add model error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to add model'
    });
  }
});

app.delete('/api/admin/models/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Check if model has associated vehicles
    const vehicles = await pool.query(
      'SELECT COUNT(*) FROM vehicles WHERE model_id = $1',
      [id]
    );
    
    if (parseInt(vehicles.rows[0].count) > 0) {
      return res.status(400).json({
        success: false,
        error: 'Cannot delete model with associated vehicles'
      });
    }
    
    await pool.query('DELETE FROM models WHERE id = $1', [id]);
    
    res.json({
      success: true,
      message: 'Model deleted successfully'
    });
  } catch (error) {
    console.error('Delete model error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete model'
    });
  }
});

// Admin vehicle management endpoints
app.delete('/api/admin/vehicles/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    await pool.query('DELETE FROM vehicles WHERE id = $1', [id]);
    
    res.json({
      success: true,
      message: 'Vehicle deleted successfully'
    });
  } catch (error) {
    console.error('Delete vehicle error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete vehicle'
    });
  }
});

app.post('/api/admin/vehicles/add-single', async (req, res) => {
  try {
    const { url, manufacturer_id, model_id, model_name } = req.body;
    
    // Basic validation
    if (!url || !manufacturer_id) {
      return res.status(400).json({
        success: false,
        error: 'URL and manufacturer are required'
      });
    }
    
    // Either model_id or model_name must be provided
    if (!model_id && !model_name) {
      return res.status(400).json({
        success: false,
        error: 'Either select a model or provide a custom model name'
      });
    }
    
    // Check if vehicle already exists
    const existing = await pool.query(
      'SELECT id FROM vehicles WHERE url = $1',
      [url]
    );
    
    if (existing.rows.length > 0) {
      return res.status(400).json({
        success: false,
        error: 'Vehicle with this URL already exists'
      });
    }
    
    // If custom model name provided, create it first
    let finalModelId = model_id;
    if (model_name && !model_id) {
      try {
        // Check if model already exists
        const existingModel = await pool.query(
          'SELECT id FROM models WHERE LOWER(name) = LOWER($1) AND manufacturer_id = $2',
          [model_name, manufacturer_id]
        );
        
        if (existingModel.rows.length > 0) {
          finalModelId = existingModel.rows[0].id;
        } else {
          // Create new model
          const newModel = await pool.query(
            'INSERT INTO models (name, manufacturer_id) VALUES ($1, $2) RETURNING id',
            [model_name, manufacturer_id]
          );
          finalModelId = newModel.rows[0].id;
          console.log(`Created new model: ${model_name} with ID ${finalModelId}`);
        }
      } catch (error) {
        console.error('Error creating model:', error);
        return res.status(500).json({
          success: false,
          error: 'Failed to create model'
        });
      }
    }
    
    // Use the single vehicle scraper to fetch and add this vehicle
    const { spawn } = require('child_process');
    const path = require('path');
    
    const scraperPath = path.join(process.cwd(), 'scrapers', 'scraper_single_vehicle.py');
    logger.info(`Starting single vehicle scraper for URL: ${url}`);
    
    const scraperProcess = spawn('python3', [
      scraperPath,
      url,
      manufacturer_id.toString(),
      finalModelId.toString()
    ], {
      stdio: ['ignore', 'pipe', 'pipe'],
      cwd: process.cwd()
    });
    
    let output = '';
    let error = '';
    
    scraperProcess.stdout.on('data', (data) => {
      output += data.toString();
      logger.info(`Single vehicle scraper stdout: ${data.toString().trim()}`);
    });
    
    scraperProcess.stderr.on('data', (data) => {
      error += data.toString();
      logger.error(`Single vehicle scraper stderr: ${data.toString().trim()}`);
    });
    
    scraperProcess.on('close', async (code) => {
      logger.info(`Single vehicle scraper finished with code: ${code}`);
      
      if (code === 0) {
        // Success - check if vehicle was added
        const newVehicle = await pool.query(
          'SELECT id FROM vehicles WHERE url = $1',
          [url]
        );
        
        if (newVehicle.rows.length > 0) {
          logger.info(`Vehicle successfully added with ID: ${newVehicle.rows[0].id}`);
          res.json({
            success: true,
            data: {
              id: newVehicle.rows[0].id
            }
          });
        } else {
          logger.error('Scraper completed but no vehicle found in database');
          res.status(500).json({
            success: false,
            error: 'Failed to add vehicle - scraper did not save data'
          });
        }
      } else {
        logger.error('Single vehicle scraper failed:', error);
        res.status(500).json({
          success: false,
          error: 'Failed to scrape vehicle data: ' + (error || 'Unknown error')
        });
      }
    });
    
    scraperProcess.on('error', (err) => {
      logger.error('Failed to start single vehicle scraper:', err);
      res.status(500).json({
        success: false,
        error: 'Failed to start scraper process'
      });
    });
    
  } catch (error) {
    console.error('Add single vehicle error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to add vehicle'
    });
  }
});

// Scraper job management endpoints
app.get('/api/admin/scraper-jobs', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        sj.*,
        m.name as manufacturer_name,
        mo.name as model_name
      FROM scraper_jobs sj
      JOIN manufacturers m ON sj.manufacturer_id = m.id
      JOIN models mo ON sj.model_id = mo.id
      ORDER BY sj.created_at DESC
      LIMIT 50
    `);
    
    res.json({
      success: true,
      data: result.rows
    });
  } catch (error) {
    console.error('Get scraper jobs error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get scraper jobs'
    });
  }
});

app.post('/api/admin/scraper-jobs', async (req, res) => {
  try {
    const { search_url, manufacturer_id, model_id, model_name } = req.body;
    
    if (!search_url || !manufacturer_id) {
      return res.status(400).json({
        success: false,
        error: 'Search URL and manufacturer are required'
      });
    }
    
    if (!model_id && !model_name) {
      return res.status(400).json({
        success: false,
        error: 'Either select a model or provide a custom model name'
      });
    }
    
    // Get manufacturer name for the robust scraper
    const manufacturerResult = await pool.query(
      'SELECT name FROM manufacturers WHERE id = $1',
      [manufacturer_id]
    );
    
    if (manufacturerResult.rows.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Invalid manufacturer ID'
      });
    }
    
    const manufacturerName = manufacturerResult.rows[0].name;
    let finalModelName = model_name;
    let finalModelId = model_id;
    
    // If model_id provided, get the model name
    if (model_id && !model_name) {
      const modelResult = await pool.query(
        'SELECT name FROM models WHERE id = $1 AND manufacturer_id = $2',
        [model_id, manufacturer_id]
      );
      
      if (modelResult.rows.length > 0) {
        finalModelName = modelResult.rows[0].name;
      } else {
        return res.status(400).json({
          success: false,
          error: 'Invalid model ID for the given manufacturer'
        });
      }
    }
    
    // If custom model name provided, the robust scraper will create it automatically
    if (model_name && !model_id) {
      // Check if model already exists (for job record)
      const existingModel = await pool.query(
        'SELECT id FROM models WHERE LOWER(name) = LOWER($1) AND manufacturer_id = $2',
        [model_name, manufacturer_id]
      );
      
      if (existingModel.rows.length > 0) {
        finalModelId = existingModel.rows[0].id;
      }
      // If not exists, set to null - the scraper will create it and we'll update later
    }
    
    // Insert job record
    const result = await pool.query(`
      INSERT INTO scraper_jobs (
        search_url, manufacturer_id, model_id, status, created_at
      ) VALUES (
        $1, $2, $3, 'pending', NOW()
      ) RETURNING id
    `, [search_url, manufacturer_id, finalModelId]);
    
    const jobId = result.rows[0].id;
    
    // Start the scraper in background
    const { spawn } = require('child_process');
    const path = require('path');
    
    // Use the proven working pattern (like Hijet scraper)
    const scraperPath = path.join(process.cwd(), 'scrapers', 'scraper_working_pattern.py');
    logger.info(`Starting robust scraper job ${jobId} with path: ${scraperPath}`);
    logger.info(`Parameters: ${manufacturerName}, ${finalModelName}`);
    
    const scraperProcess = spawn('python3', [
      scraperPath,
      search_url,
      manufacturer_id.toString(),
      finalModelId.toString(),
      jobId.toString()  
    ], {
      detached: false,  // Changed to false for better error handling
      stdio: ['ignore', 'pipe', 'pipe'],  // Capture stdout and stderr
      cwd: process.cwd()
    });
    
    // Track the process
    runningScrapers.set(jobId, {
      process: scraperProcess,
      startTime: new Date(),
      manufacturer_id,
      model_id: finalModelId,
      manufacturer_name: manufacturerName,
      model_name: finalModelName
    });
    
    // Update job with PID and running status
    await pool.query(
      'UPDATE scraper_jobs SET status = $1 WHERE id = $2',
      ['running', jobId]
    );
    
    // Log process start
    logger.info(`Scraper process started with PID: ${scraperProcess.pid} for job ${jobId}`);
    
    // Handle process output
    scraperProcess.stdout.on('data', (data) => {
      logger.info(`Scraper ${jobId} stdout: ${data.toString().trim()}`);
    });
    
    scraperProcess.stderr.on('data', (data) => {
      logger.error(`Scraper ${jobId} stderr: ${data.toString().trim()}`);
    });
    
    // Handle process exit
    scraperProcess.on('close', async (code) => {
      logger.info(`Scraper job ${jobId} finished with code: ${code}`);
      
      // Remove from running scrapers
      runningScrapers.delete(jobId);
      
      if (code !== 0) {
        try {
          await pool.query(
            'UPDATE scraper_jobs SET status = $1, error_message = $2, completed_at = NOW() WHERE id = $3',
            ['failed', `Process exited with code ${code}`, jobId]
          );
        } catch (err) {
          logger.error(`Failed to update job ${jobId} status:`, err);
        }
      }
    });
    
    scraperProcess.on('error', async (error) => {
      logger.error(`Failed to start scraper process for job ${jobId}:`, error);
      
      // Remove from running scrapers
      runningScrapers.delete(jobId);
      
      try {
        await pool.query(
          'UPDATE scraper_jobs SET status = $1, error_message = $2, completed_at = NOW() WHERE id = $3',
          ['failed', `Failed to start process: ${error.message}`, jobId]
        );
      } catch (err) {
        logger.error(`Failed to update job ${jobId} status:`, err);
      }
    });
    
    // Don't unref so we can track the process
    // scraperProcess.unref();
    
    res.json({
      success: true,
      data: { id: jobId, pid: scraperProcess.pid }
    });
  } catch (error) {
    logger.error('Create scraper job error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create scraper job'
    });
  }
});

// Cancel scraper job endpoint
app.post('/api/admin/scraper-jobs/:id/cancel', async (req, res) => {
  try {
    const jobId = parseInt(req.params.id);
    
    // Check if job exists and is running
    const job = await pool.query(
      'SELECT * FROM scraper_jobs WHERE id = $1',
      [jobId]
    );
    
    if (job.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Job not found'
      });
    }
    
    if (job.rows[0].status !== 'running' && job.rows[0].status !== 'pending') {
      return res.status(400).json({
        success: false,
        error: 'Job is not running or pending'
      });
    }
    
    // Kill the process if it's running
    const runningJob = runningScrapers.get(jobId);
    if (runningJob && runningJob.process) {
      try {
        runningJob.process.kill('SIGTERM');
        logger.info(`Killed scraper process for job ${jobId}`);
      } catch (killError) {
        logger.error(`Error killing process for job ${jobId}:`, killError);
      }
      runningScrapers.delete(jobId);
    }
    
    // Update job status to cancelled
    await pool.query(
      'UPDATE scraper_jobs SET status = $1, error_message = $2, completed_at = NOW() WHERE id = $3',
      ['cancelled', 'Job cancelled by user', jobId]
    );
    
    logger.info(`Scraper job ${jobId} cancelled by user`);
    
    res.json({
      success: true,
      message: 'Job cancelled successfully'
    });
    
  } catch (error) {
    logger.error('Cancel scraper job error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to cancel job'
    });
  }
});

// Create scraper_jobs table if it doesn't exist
pool.query(`
  CREATE TABLE IF NOT EXISTS scraper_jobs (
    id SERIAL PRIMARY KEY,
    search_url TEXT NOT NULL,
    manufacturer_id INTEGER REFERENCES manufacturers(id),
    model_id INTEGER REFERENCES models(id),
    status VARCHAR(50) DEFAULT 'pending',
    total_found INTEGER DEFAULT 0,
    total_added INTEGER DEFAULT 0,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    completed_at TIMESTAMP
  )
`).then(() => {
  console.log('✅ Scraper jobs table ready');
}).catch(err => {
  console.error('❌ Error creating scraper_jobs table:', err);
});

// Create title cleanup function in database
pool.query(`
  CREATE OR REPLACE FUNCTION cleanup_vehicle_title(input_text TEXT) 
  RETURNS TEXT AS $$
  BEGIN
    RETURN TRIM(
      REGEXP_REPLACE(
        REGEXP_REPLACE(
          REGEXP_REPLACE(
            REGEXP_REPLACE(
              REGEXP_REPLACE(
                REGEXP_REPLACE(
                  REGEXP_REPLACE(
                    REGEXP_REPLACE(
                      REGEXP_REPLACE(
                        REGEXP_REPLACE(
                          REGEXP_REPLACE(
                            REGEXP_REPLACE(
                              REGEXP_REPLACE(
                                REGEXP_REPLACE(
                                  REGEXP_REPLACE(
                                    REGEXP_REPLACE(
                                      REGEXP_REPLACE(
                                        REGEXP_REPLACE(
                                          REGEXP_REPLACE(
                                            REGEXP_REPLACE(input_text,
                                            'Landcruiser Prado', 'Land Cruiser Prado', 'gi'),
                                          'LandcruiserPrado', 'Land Cruiser Prado', 'gi'),
                                        'Land CruiserPrado', 'Land Cruiser Prado', 'gi'),
                                      'CruiserPrado', 'Cruiser Prado', 'gi'),
                                    'Landcruiser', 'Land Cruiser', 'gi'),
                                  'hilux surf', 'Hilux Surf', 'gi'),
                                'Electric sliding door on both sides', 'Dual Electric Sliding Doors', 'gi'),
                              'Both sides electric', 'Dual Electric', 'gi'),
                            'Both sides power slide', 'Dual Power Sliding', 'gi'),
                          'Rear seat monitor', 'Rear Seat Monitor', 'gi'),
                        'Around view monitor', 'Around View Monitor', 'gi'),
                      'Sun Roof', 'Sunroof', 'gi'),
                    'Back camera', 'Backup Camera', 'gi'),
                  'Air conditioner', 'Air Conditioning', 'gi'),
                'Intelligent key', 'Smart Key', 'gi'),
              'One owner car', 'One Owner', 'gi'),
            'Non smoking', 'Non-Smoking', 'gi'),
          'inch inch', 'inch', 'gi'),
        '\\s+', ' ', 'g'),
      '\\s+', ' ', 'g')
    );
  END;
  $$ LANGUAGE plpgsql IMMUTABLE;
`).then(() => {
  console.log('✅ Title cleanup function created in database');
}).catch(err => {
  console.error('❌ Error creating title cleanup function:', err);
});

// Create trigger to automatically clean titles on insert/update
pool.query(`
  CREATE OR REPLACE FUNCTION trigger_cleanup_vehicle_title() 
  RETURNS TRIGGER AS $$
  BEGIN
    NEW.title_description := cleanup_vehicle_title(NEW.title_description);
    RETURN NEW;
  END;
  $$ LANGUAGE plpgsql;
`).then(() => {
  console.log('✅ Title cleanup trigger function created');
}).catch(err => {
  console.error('❌ Error creating trigger function:', err);
});

pool.query(`
  DROP TRIGGER IF EXISTS cleanup_title_trigger ON vehicles;
  CREATE TRIGGER cleanup_title_trigger
    BEFORE INSERT OR UPDATE OF title_description ON vehicles
    FOR EACH ROW
    EXECUTE FUNCTION trigger_cleanup_vehicle_title();
`).then(() => {
  console.log('✅ Title cleanup trigger installed on vehicles table');
}).catch(err => {
  console.error('❌ Error installing trigger:', err);
});

// Admin endpoint to clean up existing vehicle titles
// SEO Management Routes
app.get('/api/admin/seo/stats', async (req, res) => {
  try {
    const stats = await seoService.getSEOStats();
    
    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error('Get SEO stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get SEO stats'
    });
  }
});

app.post('/api/admin/seo/generate', async (req, res) => {
  try {
    // Start SEO generation in background
    seoService.runSEOGeneration().catch(error => {
      console.error('Background SEO generation failed:', error);
    });

    res.json({
      success: true,
      message: 'SEO generation started in background'
    });
  } catch (error) {
    console.error('Start SEO generation error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to start SEO generation'
    });
  }
});

app.post('/api/admin/cleanup-titles', async (req, res) => {
  try {
    console.log('Starting title cleanup process...');
    
    // Get all vehicles with problematic titles
    const query = `
      SELECT id, title_description 
      FROM vehicles 
      WHERE title_description ILIKE '%CruiserPrado%' 
         OR title_description ILIKE '%Landcruiser%'
         OR title_description ~ '[ぁ-んァ-ヶー]'
      ORDER BY id
    `;
    
    const result = await pool.query(query);
    console.log(`Found ${result.rows.length} titles that need cleanup`);
    
    let successCount = 0;
    let errorCount = 0;
    
    // Process in small batches to avoid overwhelming the translation API
    for (let i = 0; i < result.rows.length; i += 5) {
      const batch = result.rows.slice(i, Math.min(i + 5, result.rows.length));
      
      console.log(`Processing batch ${Math.floor(i/5) + 1}/${Math.ceil(result.rows.length/5)}...`);
      
      for (const row of batch) {
        try {
          const cleanedTitle = await translateAndCleanTitle(row.title_description);
          
          // Update the database
          await pool.query(
            'UPDATE vehicles SET title_description = $1 WHERE id = $2',
            [cleanedTitle, row.id]
          );
          
          console.log(`✓ ID ${row.id}: ${cleanedTitle.substring(0, 80)}...`);
          successCount++;
          
        } catch (error) {
          console.error(`✗ ID ${row.id}: Cleanup failed - ${error.message}`);
          errorCount++;
        }
      }
      
      // Small delay between batches to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
    
    res.json({
      success: true,
      message: 'Title cleanup completed',
      data: {
        processed: result.rows.length,
        success: successCount,
        errors: errorCount
      }
    });
    
  } catch (error) {
    console.error('Title cleanup error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to cleanup titles',
      details: error.message
    });
  }
});

// Initialize SEO service
const seoService = new SEOService(pool);

// Start server
app.listen(port, () => {
  console.log(`Japan Direct Trucks Backend running on http://localhost:${port}`);
  console.log(`Health check: http://localhost:${port}/api/health`);
  console.log(`Featured vehicles: http://localhost:${port}/api/vehicles/featured`);
  
  // Start SEO generation service after server is running
  seoService.startAutomaticSEOGeneration();
  seoService.runSEOGeneration().catch(err => {
    logger.error('Initial SEO generation failed:', err);
  });
});

// Test database connection on startup
pool.query('SELECT NOW() as current_time, COUNT(*) as vehicle_count FROM vehicles', (err, result) => {
  if (err) {
    console.error('Database connection failed:', err.message);
  } else {
    console.log('Database connected successfully!');
    console.log(`Found ${result.rows[0].vehicle_count} vehicles in database`);
    console.log(`Server time: ${result.rows[0].current_time}`);
  }
});

// Handle graceful shutdown
process.on('SIGINT', async () => {
  console.log('\n🛑 Shutting down gracefully...');
  await pool.end();
  process.exit(0);
});